#!/bin/bash

rm -R qdata/

mkdir qdata

./istanbul-init.sh

