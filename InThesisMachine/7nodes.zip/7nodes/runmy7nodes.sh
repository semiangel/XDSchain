#!/bin/bash

./istanbul-start.sh tessera --tesseraOptions "--tesseraJar /home/pcep/Documents/7NodesTry/tessera/tessera-dist/tessera-app/target/tessera-app-0.11-SNAPSHOT-jdk11_app.jar"
